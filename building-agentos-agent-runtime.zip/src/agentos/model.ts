import type { Message, ModelCompletion, ModelProvider } from "./types";
import { AgentOSError } from "./types";

export interface OpenAICompatibleOptions {
  apiKey: string;
  baseUrl?: string;
  model?: string;
  timeoutMs?: number;
  fetchImpl?: typeof fetch;
}

/** Minimal OpenAI-compatible chat completion client (works with OpenAI, Azure-compatible proxies, Ollama, vLLM...). */
export class OpenAICompatibleProvider implements ModelProvider {
  name: string;
  constructor(private opts: OpenAICompatibleOptions) {
    this.name = `openai-compatible:${opts.model ?? "gpt-4o-mini"}`;
  }

  async complete(messages: Message[], opts: { json?: boolean; maxTokens?: number; signal?: AbortSignal } = {}): Promise<ModelCompletion> {
    const base = (this.opts.baseUrl ?? "https://api.openai.com/v1").replace(/\/$/, "");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.opts.timeoutMs ?? 120_000);
    const onAbort = () => controller.abort();
    opts.signal?.addEventListener("abort", onAbort, { once: true });
    try {
      const res = await (this.opts.fetchImpl ?? fetch)(`${base}/chat/completions`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${this.opts.apiKey}` },
        body: JSON.stringify({
          model: this.opts.model ?? "gpt-4o-mini",
          messages: messages.map((m) => ({ role: m.role === "tool" ? "user" : m.role, content: m.content })),
          temperature: 0,
          max_tokens: opts.maxTokens ?? 2048,
          ...(opts.json ? { response_format: { type: "json_object" } } : {}),
        }),
        signal: controller.signal,
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new AgentOSError("MODEL_HTTP_ERROR", `model request failed: ${res.status} ${text.slice(0, 300)}`, { retryable: res.status >= 500 || res.status === 429 });
      }
      const data = (await res.json()) as { choices?: { message?: { content?: string } }[]; usage?: { total_tokens?: number } };
      const content = data.choices?.[0]?.message?.content ?? "";
      return { content, tokens: data.usage?.total_tokens ?? Math.ceil(content.length / 4) };
    } catch (err) {
      if (err instanceof AgentOSError) throw err;
      throw new AgentOSError("MODEL_ERROR", err instanceof Error ? err.message : String(err), { retryable: true });
    } finally {
      clearTimeout(timer);
      opts.signal?.removeEventListener("abort", onAbort);
    }
  }
}

/** Returns a provider when credentials are configured, otherwise null (deterministic mode). */
export function createModelProviderFromEnv(env: NodeJS.ProcessEnv = process.env): ModelProvider | null {
  const apiKey = env.LLM_API_KEY || env.OPENAI_API_KEY;
  if (!apiKey) return null;
  return new OpenAICompatibleProvider({ apiKey, baseUrl: env.LLM_BASE_URL || env.OPENAI_BASE_URL, model: env.LLM_MODEL || env.OPENAI_MODEL });
}

/** Extracts the first JSON object/array from a model response. */
export function extractJson<T = unknown>(text: string): T {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenced ? fenced[1] : text;
  const start = Math.min(...["{", "["].map((c) => candidate.indexOf(c)).filter((i) => i >= 0));
  if (!Number.isFinite(start)) throw new AgentOSError("MODEL_BAD_JSON", "no JSON found in model output");
  const end = Math.max(candidate.lastIndexOf("}"), candidate.lastIndexOf("]"));
  return JSON.parse(candidate.slice(start, end + 1)) as T;
}
