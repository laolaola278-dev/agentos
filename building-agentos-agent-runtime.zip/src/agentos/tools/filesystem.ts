import fsp from "node:fs/promises";
import path from "node:path";
import type { Tool, ToolActionDef, ToolContext, ToolInput } from "../types";
import { ToolError } from "../types";
import { resolveSafePath } from "../security";
import { atomicWriteFile } from "../persistence";
import { optionalArg, requireArg } from "./registry";

const DEFAULT_MAX_READ_BYTES = 1024 * 1024;
const IGNORED_DIRS = new Set(["node_modules", ".git", ".next", "dist", ".agentos"]);

function isBinary(buf: Buffer): boolean {
  const n = Math.min(buf.length, 8000);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}

function mapFsError(err: unknown, p: string): never {
  const e = err as NodeJS.ErrnoException;
  if (e?.code === "ENOENT") throw new ToolError("NOT_FOUND", `no such file or directory: ${p}`);
  if (e?.code === "EACCES" || e?.code === "EPERM") throw new ToolError("PERMISSION_DENIED", `permission denied: ${p}`);
  if (e?.code === "EISDIR") throw new ToolError("IS_DIRECTORY", `is a directory: ${p}`);
  if (e?.code === "ENOTDIR") throw new ToolError("NOT_DIRECTORY", `not a directory: ${p}`);
  if (e?.code === "EEXIST") throw new ToolError("ALREADY_EXISTS", `already exists: ${p}`);
  if (e?.code === "EBUSY") throw new ToolError("BUSY", `resource busy: ${p}`, { retryable: true });
  throw err;
}

export class FilesystemTool implements Tool {
  name = "filesystem";
  description = "Sandboxed filesystem access limited to the task workdir";
  actions: ToolActionDef[] = [
    { name: "read", description: "Read a text file", params: { path: "string", maxBytes: "number?", encoding: "utf8|base64?" } },
    { name: "write", description: "Write a file atomically (creates parents)", params: { path: "string", content: "string" } },
    { name: "append", description: "Append to a file", params: { path: "string", content: "string" } },
    { name: "edit", description: "Replace text in a file", params: { path: "string", oldText: "string", newText: "string", all: "boolean?" } },
    { name: "delete", description: "Delete a file or directory", params: { path: "string", recursive: "boolean?" } },
    { name: "move", description: "Move/rename", params: { from: "string", to: "string" } },
    { name: "copy", description: "Copy file or directory", params: { from: "string", to: "string" } },
    { name: "list", description: "List directory entries", params: { path: "string?", recursive: "boolean?", maxEntries: "number?" } },
    { name: "search", description: "Regex search across files", params: { pattern: "string", path: "string?", glob: "string?", maxResults: "number?" } },
    { name: "mkdir", description: "Create directory", params: { path: "string" } },
    { name: "stat", description: "File metadata", params: { path: "string" } },
    { name: "exists", description: "Check existence", params: { path: "string" } },
  ];

  async execute(input: ToolInput, ctx: ToolContext): Promise<unknown> {
    const a = input.args ?? {};
    const safe = (p: string) => resolveSafePath(ctx.workdir, p);
    switch (input.action) {
      case "read":
        return this.read(safe(requireArg(a, "path")), optionalArg(a, "maxBytes", DEFAULT_MAX_READ_BYTES), optionalArg(a, "encoding", "utf8"));
      case "write": {
        const p = safe(requireArg(a, "path"));
        const content = requireArg<string>(a, "content");
        try {
          await atomicWriteFile(p, content);
        } catch (err) {
          mapFsError(err, p);
        }
        return { path: p, bytes: Buffer.byteLength(content) };
      }
      case "append": {
        const p = safe(requireArg(a, "path"));
        const content = requireArg<string>(a, "content");
        try {
          await fsp.mkdir(path.dirname(p), { recursive: true });
          await fsp.appendFile(p, content, "utf8");
        } catch (err) {
          mapFsError(err, p);
        }
        return { path: p, bytes: Buffer.byteLength(content) };
      }
      case "edit": {
        const p = safe(requireArg(a, "path"));
        const oldText = requireArg<string>(a, "oldText");
        const newText = requireArg<string>(a, "newText");
        const all = optionalArg(a, "all", false);
        let text: string;
        try {
          text = await fsp.readFile(p, "utf8");
        } catch (err) {
          mapFsError(err, p);
        }
        const count = text!.split(oldText).length - 1;
        if (count === 0) throw new ToolError("EDIT_NO_MATCH", `oldText not found in ${p}`);
        if (count > 1 && !all) throw new ToolError("EDIT_AMBIGUOUS", `oldText matches ${count} times in ${p}; pass all=true`);
        const updated = all ? text!.split(oldText).join(newText) : text!.replace(oldText, () => newText);
        await atomicWriteFile(p, updated);
        return { path: p, replacements: all ? count : 1 };
      }
      case "delete": {
        const p = safe(requireArg(a, "path"));
        if (path.resolve(p) === path.resolve(ctx.workdir)) throw new ToolError("REFUSED", "refusing to delete the workdir root");
        try {
          const st = await fsp.lstat(p);
          if (st.isDirectory() && !optionalArg(a, "recursive", false)) throw new ToolError("IS_DIRECTORY", `pass recursive=true to delete directory ${p}`);
          await fsp.rm(p, { recursive: st.isDirectory(), force: false });
        } catch (err) {
          if (err instanceof ToolError) throw err;
          mapFsError(err, p);
        }
        return { path: p, deleted: true };
      }
      case "move": {
        const from = safe(requireArg(a, "from"));
        const to = safe(requireArg(a, "to"));
        try {
          await fsp.mkdir(path.dirname(to), { recursive: true });
          await fsp.rename(from, to);
        } catch (err) {
          mapFsError(err, from);
        }
        return { from, to };
      }
      case "copy": {
        const from = safe(requireArg(a, "from"));
        const to = safe(requireArg(a, "to"));
        try {
          await fsp.mkdir(path.dirname(to), { recursive: true });
          await fsp.cp(from, to, { recursive: true, errorOnExist: false });
        } catch (err) {
          mapFsError(err, from);
        }
        return { from, to };
      }
      case "list":
        return this.list(safe(optionalArg(a, "path", ".")), optionalArg(a, "recursive", false), optionalArg(a, "maxEntries", 2000), ctx);
      case "search":
        return this.search(
          safe(optionalArg(a, "path", ".")),
          requireArg(a, "pattern"),
          optionalArg<string | undefined>(a, "glob", undefined),
          optionalArg(a, "maxResults", 200),
          ctx,
        );
      case "mkdir": {
        const p = safe(requireArg(a, "path"));
        await fsp.mkdir(p, { recursive: true });
        return { path: p };
      }
      case "stat": {
        const p = safe(requireArg(a, "path"));
        try {
          const st = await fsp.stat(p);
          return { path: p, size: st.size, isFile: st.isFile(), isDirectory: st.isDirectory(), mtime: st.mtime.toISOString(), mode: st.mode };
        } catch (err) {
          mapFsError(err, p);
        }
        break;
      }
      case "exists": {
        const p = safe(requireArg(a, "path"));
        try {
          await fsp.access(p);
          return { path: p, exists: true };
        } catch {
          return { path: p, exists: false };
        }
      }
      default:
        throw new ToolError("UNKNOWN_ACTION", `unknown filesystem action ${input.action}`);
    }
  }

  private async read(p: string, maxBytes: number, encoding: string) {
    let handle: fsp.FileHandle;
    try {
      handle = await fsp.open(p, "r");
    } catch (err) {
      mapFsError(err, p);
    }
    try {
      const st = await handle!.stat();
      if (st.isDirectory()) throw new ToolError("IS_DIRECTORY", `is a directory: ${p}`);
      const toRead = Math.min(st.size, maxBytes);
      const buf = Buffer.alloc(toRead);
      await handle!.read(buf, 0, toRead, 0);
      const binary = isBinary(buf);
      if (binary && encoding !== "base64") {
        return { path: p, binary: true, size: st.size, content: null, note: "binary file; request encoding=base64 to read" };
      }
      return {
        path: p,
        size: st.size,
        binary,
        truncated: st.size > maxBytes,
        content: encoding === "base64" ? buf.toString("base64") : buf.toString("utf8"),
      };
    } finally {
      await handle!.close();
    }
  }

  private async list(dir: string, recursive: boolean, maxEntries: number, ctx: ToolContext) {
    const entries: { path: string; type: "file" | "dir" | "symlink" | "other"; size?: number }[] = [];
    let truncated = false;
    const walk = async (d: string): Promise<void> => {
      if (ctx.signal.aborted) throw ctx.signal.reason;
      let dirents;
      try {
        dirents = await fsp.readdir(d, { withFileTypes: true });
      } catch (err) {
        mapFsError(err, d);
      }
      for (const de of dirents!) {
        if (entries.length >= maxEntries) {
          truncated = true;
          return;
        }
        const full = path.join(d, de.name);
        const rel = path.relative(ctx.workdir, full) || ".";
        const type = de.isDirectory() ? "dir" : de.isFile() ? "file" : de.isSymbolicLink() ? "symlink" : "other";
        let size: number | undefined;
        if (type === "file") {
          try {
            size = (await fsp.stat(full)).size;
          } catch {
            size = undefined;
          }
        }
        entries.push({ path: rel, type, size });
        if (recursive && type === "dir" && !IGNORED_DIRS.has(de.name)) await walk(full);
      }
    };
    await walk(dir);
    return { entries, truncated };
  }

  private async search(dir: string, pattern: string, glob: string | undefined, maxResults: number, ctx: ToolContext) {
    let re: RegExp;
    try {
      re = new RegExp(pattern);
    } catch {
      throw new ToolError("INVALID_ARGUMENT", `invalid regex: ${pattern}`);
    }
    const globRe = glob ? globToRegExp(glob) : null;
    const matches: { file: string; line: number; text: string }[] = [];
    let filesScanned = 0;
    const walk = async (d: string): Promise<void> => {
      if (matches.length >= maxResults) return;
      if (ctx.signal.aborted) throw ctx.signal.reason;
      const dirents = await fsp.readdir(d, { withFileTypes: true }).catch(() => []);
      for (const de of dirents) {
        const full = path.join(d, de.name);
        if (de.isDirectory()) {
          if (!IGNORED_DIRS.has(de.name)) await walk(full);
        } else if (de.isFile()) {
          const rel = path.relative(ctx.workdir, full);
          if (globRe && !globRe.test(rel) && !globRe.test(de.name)) continue;
          let buf: Buffer;
          try {
            buf = await fsp.readFile(full);
          } catch {
            continue;
          }
          if (buf.length > 4 * 1024 * 1024 || isBinary(buf)) continue;
          filesScanned++;
          const lines = buf.toString("utf8").split("\n");
          for (let i = 0; i < lines.length; i++) {
            if (re.test(lines[i])) {
              matches.push({ file: rel, line: i + 1, text: lines[i].slice(0, 500) });
              if (matches.length >= maxResults) return;
            }
          }
        }
      }
    };
    await walk(dir);
    return { matches, filesScanned, truncated: matches.length >= maxResults };
  }
}

export function globToRegExp(glob: string): RegExp {
  const escaped = glob
    .replace(/[.+^${}()|[\]\\]/g, "\\$&")
    .replace(/\*\*\//g, "(?:.*/)?")
    .replace(/\*\*/g, ".*")
    .replace(/\*/g, "[^/]*")
    .replace(/\?/g, "[^/]");
  return new RegExp(`^${escaped}$`);
}
