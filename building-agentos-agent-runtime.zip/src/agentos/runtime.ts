import path from "node:path";
import fsp from "node:fs/promises";
import { randomBytes } from "node:crypto";
import type { Checkpoint, ModelProvider, Task, TaskSpec, TaskStatus } from "./types";
import { ACTIVE_STATUSES, AgentOSError, DEFAULT_BUDGET, TERMINAL_STATUSES, nowIso } from "./types";
import { FilePersistence, MemoryPersistence, SqlitePersistence, type Persistence } from "./persistence";
import { EventBus } from "./events";
import { createDefaultToolRegistry, ProcessManager, ToolRegistry } from "./tools";
import { VerificationEngine } from "./verification";
import { TaskQueue } from "./queue";
import { Orchestrator } from "./orchestrator";
import { MetricsCollector } from "./metrics";
import { createModelProviderFromEnv } from "./model";
import { AGENT_CATALOG } from "./agents";
import { getGitState } from "./tools/git";

export type PersistenceKind = "memory" | "file" | "sqlite";

export interface RuntimeOptions {
  rootDir?: string;
  dataDir?: string;
  persistence?: Persistence | PersistenceKind;
  concurrency?: number;
  model?: ModelProvider | null;
  jsonlMirror?: boolean;
  controlPollMs?: number;
  allowDangerousCommands?: boolean;
  tools?: ToolRegistry;
  heartbeatMs?: number;
  defaultBudget?: Partial<typeof DEFAULT_BUDGET>;
}

interface RunningEntry {
  controller: AbortController;
  promise: Promise<Task>;
}

export interface DoctorReport {
  ok: boolean;
  checks: { name: string; ok: boolean; detail: string }[];
}

/** Keeps `.agentos/` out of `git status` without editing the user's .gitignore (uses .git/info/exclude). */
async function excludeDataDirFromGit(rootDir: string, dataDir: string): Promise<void> {
  const rel = path.relative(rootDir, dataDir);
  if (!rel || rel.startsWith("..") || path.isAbsolute(rel)) return;
  const gitDir = path.join(rootDir, ".git");
  try {
    if (!(await fsp.stat(gitDir)).isDirectory()) return;
  } catch {
    return;
  }
  const excludeFile = path.join(gitDir, "info", "exclude");
  const line = `/${rel.split(path.sep).join("/")}/`;
  try {
    const existing = await fsp.readFile(excludeFile, "utf8").catch(() => "");
    if (existing.split("\n").some((l) => l.trim() === line)) return;
    await fsp.mkdir(path.dirname(excludeFile), { recursive: true });
    await fsp.appendFile(excludeFile, `${existing.endsWith("\n") || existing === "" ? "" : "\n"}${line}\n`);
  } catch {
    // best effort
  }
}

export function newTaskId(): string {
  return `task_${Date.now().toString(36)}_${randomBytes(4).toString("hex")}`;
}

/**
 * AgentRuntime — the public façade. Owns persistence, the event bus, tools, the scheduler
 * and the per-task orchestrators. All mutations of task state go through here.
 */
export class AgentRuntime {
  readonly rootDir: string;
  readonly dataDir: string;
  readonly persistence: Persistence;
  readonly bus: EventBus;
  readonly tools: ToolRegistry;
  readonly processes: ProcessManager;
  readonly verification = new VerificationEngine();
  readonly metrics = new MetricsCollector();
  readonly queue = new TaskQueue();
  readonly model: ModelProvider | null;
  readonly concurrency: number;
  private orchestrator: Orchestrator;
  private running = new Map<string, RunningEntry>();
  private waiters = new Map<string, ((t: Task) => void)[]>();
  private controlTimer: NodeJS.Timeout | null = null;
  private daemonTimer: NodeJS.Timeout | null = null;
  private closed = false;
  private scheduling = false;
  private defaultBudget: typeof DEFAULT_BUDGET;

  private constructor(opts: RuntimeOptions, persistence: Persistence) {
    this.rootDir = path.resolve(opts.rootDir ?? process.cwd());
    this.dataDir = path.resolve(opts.dataDir ?? path.join(this.rootDir, ".agentos"));
    this.persistence = persistence;
    this.bus = new EventBus(persistence, { jsonlMirror: opts.jsonlMirror ? path.join(this.dataDir, "events.jsonl") : undefined });
    const created = createDefaultToolRegistry({ allowDangerous: opts.allowDangerousCommands });
    this.tools = opts.tools ?? created.registry;
    this.processes = created.processes;
    this.model = opts.model === undefined ? createModelProviderFromEnv() : opts.model;
    this.concurrency = Math.max(1, opts.concurrency ?? 2);
    this.defaultBudget = { ...DEFAULT_BUDGET, ...(opts.defaultBudget ?? {}) };
    this.orchestrator = new Orchestrator({ persistence, bus: this.bus, tools: this.tools, verification: this.verification, model: this.model, dataDir: this.dataDir, heartbeatMs: opts.heartbeatMs });
    this.metrics.attach(this.bus);
    const pollMs = opts.controlPollMs ?? 500;
    if (pollMs > 0) {
      this.controlTimer = setInterval(() => this.pollControl().catch(() => undefined), pollMs);
      this.controlTimer.unref();
    }
  }

  static async create(opts: RuntimeOptions = {}): Promise<AgentRuntime> {
    const rootDir = path.resolve(opts.rootDir ?? process.cwd());
    const dataDir = path.resolve(opts.dataDir ?? path.join(rootDir, ".agentos"));
    await fsp.mkdir(dataDir, { recursive: true });
    let persistence: Persistence;
    const p = opts.persistence ?? "sqlite";
    if (typeof p === "string") {
      persistence = p === "memory" ? new MemoryPersistence() : p === "file" ? new FilePersistence(path.join(dataDir, "store")) : new SqlitePersistence(path.join(dataDir, "agentos.db"));
    } else persistence = p;
    await persistence.init();
    await excludeDataDirFromGit(rootDir, dataDir);
    const rt = new AgentRuntime({ ...opts, rootDir, dataDir }, persistence);
    await rt.bus.syncSequence();
    for (const t of await persistence.listTasks()) rt.queue.upsert(t);
    return rt;
  }

  // ---- task lifecycle ------------------------------------------------------

  async createTask(spec: TaskSpec): Promise<Task> {
    if (!spec || typeof spec.title !== "string" || !spec.title.trim()) throw new AgentOSError("INVALID_SPEC", "task title is required");
    if (typeof spec.goal !== "string") throw new AgentOSError("INVALID_SPEC", "task goal is required");
    const workdir = path.resolve(this.rootDir, spec.workdir ?? ".");
    try {
      const st = await fsp.stat(workdir);
      if (!st.isDirectory()) throw new Error("not a directory");
    } catch {
      throw new AgentOSError("INVALID_SPEC", `workdir does not exist: ${workdir}`);
    }
    const now = nowIso();
    const task: Task = {
      id: newTaskId(),
      spec: { ...spec, workdir },
      status: "CREATED",
      priority: Number.isFinite(spec.priority) ? Number(spec.priority) : 0,
      dependsOn: [...new Set(spec.dependsOn ?? [])],
      budget: { ...this.defaultBudget, ...(spec.budget ?? {}) },
      usage: { toolCalls: 0, tokens: 0, retries: 0, fixes: 0, elapsedMs: 0 },
      attempt: 0,
      workdir,
      createdAt: now,
      updatedAt: now,
    };
    this.queue.validateDependencies(task);
    this.queue.upsert(task);
    await this.persistence.saveTask(task);
    await this.bus.emit({ taskId: task.id, agentId: null, type: "task.created", data: { title: spec.title, priority: task.priority, dependsOn: task.dependsOn } });
    return task;
  }

  getTask(id: string): Task | undefined {
    return this.queue.get(id);
  }

  async loadTask(id: string): Promise<Task | null> {
    return this.queue.get(id) ?? (await this.persistence.getTask(id));
  }

  listTasks(status?: TaskStatus[]): Task[] {
    return this.queue
      .all()
      .filter((t) => !status || status.includes(t.status))
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  }

  /** Enqueue a task; the scheduler starts it when dependencies are met and a slot is free. */
  async startTask(id: string): Promise<Task> {
    const task = this.requireTask(id);
    if (this.running.has(id)) throw new AgentOSError("ALREADY_RUNNING", `task ${id} is already running`);
    if (!["CREATED", "PAUSED", "QUEUED", "FAILED", "CANCELLED", "BLOCKED"].includes(task.status)) {
      throw new AgentOSError("INVALID_TRANSITION", `cannot start task in status ${task.status}`);
    }
    if (task.status !== "PAUSED") await this.persistence.deleteCheckpoint(id);
    await this.setStatus(task, "QUEUED", "task.queued");
    this.schedule();
    return task;
  }

  /** Enqueue and wait for a terminal or paused state. */
  async runTask(id: string): Promise<Task> {
    await this.startTask(id);
    return this.waitForTask(id);
  }

  async pauseTask(id: string): Promise<Task> {
    const task = this.requireTask(id);
    const entry = this.running.get(id);
    if (entry) {
      entry.controller.abort("pause");
      return entry.promise;
    }
    if (task.status === "QUEUED") {
      await this.setStatus(task, "PAUSED", "task.paused");
      return task;
    }
    throw new AgentOSError("INVALID_TRANSITION", `cannot pause task in status ${task.status}`);
  }

  async resumeTask(id: string): Promise<Task> {
    const task = this.requireTask(id);
    if (task.status !== "PAUSED") throw new AgentOSError("INVALID_TRANSITION", `cannot resume task in status ${task.status}`);
    await this.setStatus(task, "QUEUED", "task.queued");
    this.schedule();
    return task;
  }

  async cancelTask(id: string): Promise<Task> {
    const task = this.requireTask(id);
    const entry = this.running.get(id);
    if (entry) {
      entry.controller.abort("cancel");
      return entry.promise;
    }
    if (TERMINAL_STATUSES.includes(task.status)) throw new AgentOSError("INVALID_TRANSITION", `task already ${task.status}`);
    task.finishedAt = nowIso();
    await this.setStatus(task, "CANCELLED", "task.cancelled");
    await this.persistence.deleteCheckpoint(id);
    this.resolveWaiters(task);
    this.schedule();
    return task;
  }

  /** Retry a FAILED/CANCELLED task from scratch (new attempt counter, fresh checkpoint). */
  async retryTask(id: string): Promise<Task> {
    const task = this.requireTask(id);
    if (!["FAILED", "CANCELLED", "BLOCKED"].includes(task.status)) throw new AgentOSError("INVALID_TRANSITION", `cannot retry task in status ${task.status}`);
    task.attempt = 0;
    task.error = undefined;
    task.result = undefined;
    task.finishedAt = undefined;
    task.startedAt = undefined;
    task.usage = { toolCalls: 0, tokens: 0, retries: task.usage.retries + 1, fixes: 0, elapsedMs: 0 };
    await this.persistence.deleteCheckpoint(id);
    await this.bus.emit({ taskId: id, agentId: null, type: "agent.retry", data: { scope: "manual" } });
    return this.startTask(id);
  }

  /**
   * Recover a task interrupted by a crash: load its checkpoint, verify the environment,
   * and resume from the last saved phase/step.
   */
  async recoverTask(id: string): Promise<{ task: Task; checkpoint: Checkpoint | null; warnings: string[] }> {
    const task = this.requireTask(id);
    if (this.running.has(id)) throw new AgentOSError("ALREADY_RUNNING", `task ${id} is already running`);
    const checkpoint = await this.persistence.loadCheckpoint(id);
    const warnings: string[] = [];
    if (!checkpoint) {
      if (ACTIVE_STATUSES.includes(task.status) || task.status === "QUEUED") {
        warnings.push("no checkpoint found; restarting from scratch");
        await this.persistence.deleteCheckpoint(id);
        await this.setStatus(task, "QUEUED", "task.queued");
        this.schedule();
      }
      return { task, checkpoint: null, warnings };
    }
    try {
      await fsp.access(checkpoint.workdir);
    } catch {
      task.status = "FAILED";
      task.error = `RECOVERY_FAILED: workdir missing: ${checkpoint.workdir}`;
      await this.persistence.saveTask(task);
      await this.bus.emit({ taskId: id, agentId: null, type: "task.failed", error: task.error, data: { recovery: true } });
      return { task, checkpoint, warnings: [task.error] };
    }
    if (checkpoint.worktree) {
      try {
        await fsp.access(checkpoint.worktree.path);
      } catch {
        warnings.push("isolated worktree missing; restarting attempt from scratch");
        await this.persistence.deleteCheckpoint(id);
        await this.setStatus(task, "QUEUED", "task.queued");
        this.schedule();
        return { task, checkpoint: null, warnings };
      }
    }
    const git = await getGitState(checkpoint.workdir);
    if (checkpoint.git?.isRepo && git.isRepo && checkpoint.git.head && git.head && checkpoint.git.head !== git.head) {
      warnings.push(`git HEAD changed since checkpoint (${checkpoint.git.head.slice(0, 8)} -> ${git.head.slice(0, 8)})`);
    }
    if (TERMINAL_STATUSES.includes(checkpoint.phase)) {
      warnings.push(`checkpoint already in terminal phase ${checkpoint.phase}`);
      return { task, checkpoint, warnings };
    }
    await this.bus.emit({ taskId: id, agentId: null, type: "task.recovering", data: { phase: checkpoint.phase, version: checkpoint.version, steps: checkpoint.completedSteps.length, warnings } });
    task.status = "PAUSED"; // normalise: recovery = resume from checkpoint
    await this.persistence.saveTask(task);
    await this.setStatus(task, "QUEUED", "task.queued");
    this.schedule();
    return { task, checkpoint, warnings };
  }

  /** Recovers every task that was active (or queued) when the previous process died. */
  async recoverAll(): Promise<{ recovered: string[]; warnings: Record<string, string[]> }> {
    const recovered: string[] = [];
    const warnings: Record<string, string[]> = {};
    for (const t of this.queue.all()) {
      if (this.running.has(t.id)) continue;
      if (ACTIVE_STATUSES.includes(t.status) || t.status === "QUEUED") {
        const r = await this.recoverTask(t.id);
        recovered.push(t.id);
        if (r.warnings.length) warnings[t.id] = r.warnings;
      }
    }
    return { recovered, warnings };
  }

  /** Tasks that would be recovered by recoverAll (diagnostics). */
  interruptedTasks(): Task[] {
    return this.queue.all().filter((t) => ACTIVE_STATUSES.includes(t.status) || t.status === "QUEUED");
  }

  waitForTask(id: string): Promise<Task> {
    const task = this.requireTask(id);
    if (TERMINAL_STATUSES.includes(task.status) || task.status === "PAUSED" || task.status === "BLOCKED") return Promise.resolve(task);
    const entry = this.running.get(id);
    if (entry) return entry.promise;
    return new Promise((resolve) => {
      const list = this.waiters.get(id) ?? [];
      list.push(resolve);
      this.waiters.set(id, list);
    });
  }

  async waitForIdle(): Promise<void> {
    while (this.running.size > 0 || this.queue.ready().length > 0) {
      await Promise.all([...this.running.values()].map((e) => e.promise));
      this.schedule();
      await new Promise((r) => setTimeout(r, 5));
    }
  }

  runningCount(): number {
    return this.running.size;
  }

  // ---- scheduler ------------------------------------------------------------

  private schedule(): void {
    if (this.closed || this.scheduling) return;
    this.scheduling = true;
    try {
      for (const blocked of this.queue.blocked()) {
        const dead = this.queue.deadDependencies(blocked);
        blocked.error = `BLOCKED: dependency ${dead.join(", ")} did not complete`;
        blocked.finishedAt = nowIso();
        void this.setStatus(blocked, "BLOCKED", "task.blocked", { dependencies: dead }).then(() => this.resolveWaiters(blocked));
      }
      for (const task of this.queue.ready()) {
        if (this.running.size >= this.concurrency) break;
        if (this.running.has(task.id)) continue;
        this.launch(task);
      }
    } finally {
      this.scheduling = false;
    }
  }

  private launch(task: Task): void {
    const controller = new AbortController();
    const promise = (async (): Promise<Task> => {
      let result: Task = task;
      try {
        const checkpoint = await this.persistence.loadCheckpoint(task.id);
        const resumable = checkpoint && !TERMINAL_STATUSES.includes(checkpoint.phase) && checkpoint.taskId === task.id;
        task.status = resumable ? checkpoint!.phase : "PLANNING";
        result = await this.orchestrator.run(task, { signal: controller.signal, checkpoint: resumable ? checkpoint : null });
      } catch (err) {
        // orchestrator handles its own errors; this is a last-resort guard so the scheduler never dies
        task.status = "FAILED";
        task.error = `RUNTIME_ERROR: ${err instanceof Error ? err.message : String(err)}`;
        task.finishedAt = nowIso();
        await this.persistence.saveTask(task).catch(() => undefined);
        await this.bus.emit({ taskId: task.id, agentId: null, type: "task.failed", error: task.error, data: { fatal: true } });
        result = task;
      } finally {
        this.processes.stopAllForTask(task.id);
        if (TERMINAL_STATUSES.includes(task.status)) await this.persistence.deleteCheckpoint(task.id).catch(() => undefined);
        this.running.delete(task.id);
        this.queue.upsert(task);
        this.resolveWaiters(task);
        await this.clearControl(task.id);
        setImmediate(() => this.schedule());
      }
      return result;
    })();
    this.running.set(task.id, { controller, promise });
    this.queue.upsert(task);
  }

  private resolveWaiters(task: Task) {
    const list = this.waiters.get(task.id);
    if (!list) return;
    this.waiters.delete(task.id);
    for (const w of list) w(task);
  }

  private requireTask(id: string): Task {
    const t = this.queue.get(id);
    if (!t) throw new AgentOSError("TASK_NOT_FOUND", `task not found: ${id}`);
    return t;
  }

  private async setStatus(task: Task, status: TaskStatus, eventType: string, data: Record<string, unknown> = {}) {
    task.status = status;
    task.updatedAt = nowIso();
    this.queue.upsert(task);
    await this.persistence.saveTask(task);
    await this.bus.emit({ taskId: task.id, agentId: null, type: eventType, data: { ...data, status } });
  }

  // ---- cross-process control channel ----------------------------------------

  private controlDir(): string {
    return path.join(this.dataDir, "control");
  }

  /** Write a control command for a task that is running in another process. */
  async sendControl(taskId: string, command: "pause" | "cancel"): Promise<void> {
    await fsp.mkdir(this.controlDir(), { recursive: true });
    await fsp.writeFile(path.join(this.controlDir(), `${taskId}.json`), JSON.stringify({ command, ts: nowIso(), pid: process.pid }));
  }

  private async clearControl(taskId: string) {
    await fsp.rm(path.join(this.controlDir(), `${taskId}.json`), { force: true }).catch(() => undefined);
  }

  private async pollControl(): Promise<void> {
    if (this.running.size === 0) return;
    let files: string[];
    try {
      files = await fsp.readdir(this.controlDir());
    } catch {
      return;
    }
    for (const f of files) {
      const taskId = f.replace(/\.json$/, "");
      const entry = this.running.get(taskId);
      if (!entry) continue;
      try {
        const cmd = JSON.parse(await fsp.readFile(path.join(this.controlDir(), f), "utf8")) as { command: string };
        if (cmd.command === "pause" || cmd.command === "cancel") {
          await this.bus.emit({ taskId, agentId: null, type: "task.control", data: { command: cmd.command, source: "control-file" } });
          entry.controller.abort(cmd.command);
        }
      } catch {
        // partial write — retry on next poll
        continue;
      }
      await this.clearControl(taskId);
    }
  }

  // ---- daemon mode: pick up QUEUED tasks written by other processes ----------

  startDaemon(pollMs = 1000): void {
    if (this.daemonTimer) return;
    this.daemonTimer = setInterval(async () => {
      if (this.closed) return;
      try {
        const persisted = await this.persistence.listTasks({ status: ["QUEUED", "CREATED", "PAUSED", "COMPLETED", "FAILED", "CANCELLED"] });
        for (const t of persisted) {
          const known = this.queue.get(t.id);
          if (this.running.has(t.id)) continue;
          if (!known || known.updatedAt < t.updatedAt) this.queue.upsert(t);
        }
        this.schedule();
      } catch {
        // storage hiccup — try again next tick
      }
    }, pollMs);
    this.daemonTimer.unref();
  }

  stopDaemon(): void {
    if (this.daemonTimer) clearInterval(this.daemonTimer);
    this.daemonTimer = null;
  }

  // ---- introspection -------------------------------------------------------

  listAgents() {
    return AGENT_CATALOG;
  }

  listTools() {
    return this.tools.list();
  }

  async doctor(): Promise<DoctorReport> {
    const checks: DoctorReport["checks"] = [];
    const major = Number(process.versions.node.split(".")[0]);
    checks.push({ name: "node", ok: major >= 20, detail: `node ${process.versions.node}` });
    try {
      await fsp.access(this.dataDir);
      const probe = path.join(this.dataDir, `.probe-${process.pid}`);
      await fsp.writeFile(probe, "ok");
      await fsp.rm(probe);
      checks.push({ name: "dataDir", ok: true, detail: `${this.dataDir} writable` });
    } catch (err) {
      checks.push({ name: "dataDir", ok: false, detail: `${this.dataDir} not writable: ${err instanceof Error ? err.message : err}` });
    }
    try {
      const n = await this.persistence.countEvents();
      checks.push({ name: "persistence", ok: true, detail: `${this.persistence.kind} store, ${n} events, ${this.queue.size()} tasks` });
    } catch (err) {
      checks.push({ name: "persistence", ok: false, detail: err instanceof Error ? err.message : String(err) });
    }
    const git = await getGitState(this.rootDir);
    checks.push({ name: "git", ok: true, detail: git.isRepo ? `repo on ${git.branch} @ ${git.head?.slice(0, 8)}${git.dirty ? " (dirty)" : ""}` : "rootDir is not a git repository (git tool still available)" });
    try {
      const { runCommand } = await import("./tools/terminal");
      const r = await runCommand("git --version && bash --version | head -1", { cwd: this.rootDir, timeoutMs: 5000 });
      checks.push({ name: "shell", ok: r.exitCode === 0, detail: r.stdout.trim().split("\n").join("; ") || r.stderr.trim() });
    } catch (err) {
      checks.push({ name: "shell", ok: false, detail: err instanceof Error ? err.message : String(err) });
    }
    checks.push({ name: "model", ok: true, detail: this.model ? `provider ${this.model.name}` : "no LLM configured — deterministic planner only (set LLM_API_KEY to enable)" });
    const interrupted = this.interruptedTasks();
    checks.push({ name: "interrupted", ok: true, detail: interrupted.length ? `${interrupted.length} task(s) need recovery: ${interrupted.map((t) => t.id).join(", ")}` : "no interrupted tasks" });
    const stats = this.bus.stats;
    checks.push({ name: "eventBus", ok: stats.pending === 0, detail: `seq=${stats.seq} pending=${stats.pending} dropped=${stats.droppedEvents} persistErrors=${stats.persistErrors}` });
    return { ok: checks.every((c) => c.ok), checks };
  }

  async close(): Promise<void> {
    this.closed = true;
    if (this.controlTimer) clearInterval(this.controlTimer);
    this.stopDaemon();
    for (const entry of this.running.values()) entry.controller.abort("pause");
    await Promise.allSettled([...this.running.values()].map((e) => e.promise));
    await this.processes.shutdown();
    await this.bus.flushPending();
    this.metrics.detach();
    await this.persistence.close();
  }
}
