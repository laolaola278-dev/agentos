import fsp from "node:fs/promises";
import path from "node:path";
import type { AcceptanceCheck, VerificationKind, VerificationResult, VerificationSpec } from "./types";
import { runCommand } from "./tools/terminal";
import type { EventBus } from "./events";
import { resolveSafePath } from "./security";

export const VERIFICATION_PRESETS: Record<Exclude<VerificationKind, "custom">, string> = {
  unit: "npm test",
  integration: "npm run test:integration",
  e2e: "npm run test:e2e",
  lint: "npm run lint",
  typecheck: "npm run typecheck",
  build: "npm run build",
};

export interface VerifyOptions {
  workdir: string;
  signal?: AbortSignal;
  artifactsDir?: string;
  taskId?: string;
  agentId?: string;
  bus?: EventBus | null;
  defaultTimeoutMs?: number;
}

/**
 * Independent verification engine: runs objective checks (tests, lint, typecheck, build, custom commands)
 * and returns structured evidence. Agents may not declare success without a passing VerificationResult.
 */
export class VerificationEngine {
  async run(spec: VerificationSpec, opts: VerifyOptions): Promise<VerificationResult> {
    const command = spec.command || (spec.kind !== "custom" ? VERIFICATION_PRESETS[spec.kind] : "");
    const cwd = spec.cwd ? resolveSafePath(opts.workdir, spec.cwd) : opts.workdir;
    const timeoutMs = spec.timeoutMs ?? opts.defaultTimeoutMs ?? 5 * 60_000;
    const base = { taskId: opts.taskId ?? null, agentId: opts.agentId ?? null, tool: "verification" };
    await opts.bus?.emit({ ...base, type: "test.started", data: { name: spec.name, kind: spec.kind, command } });
    let result: VerificationResult;
    if (!command) {
      result = { name: spec.name, kind: spec.kind, command, passed: false, exitCode: null, stdout: "", stderr: "no command configured", durationMs: 0, artifacts: [], timedOut: false };
    } else {
      try {
        const r = await runCommand(command, { cwd, timeoutMs, signal: opts.signal, maxOutputBytes: 512 * 1024 });
        result = {
          name: spec.name,
          kind: spec.kind,
          command,
          passed: r.exitCode === 0 && !r.timedOut && !r.killed,
          exitCode: r.exitCode,
          stdout: r.stdout,
          stderr: r.stderr,
          durationMs: r.durationMs,
          artifacts: [],
          timedOut: r.timedOut,
        };
      } catch (err) {
        result = { name: spec.name, kind: spec.kind, command, passed: false, exitCode: null, stdout: "", stderr: err instanceof Error ? err.message : String(err), durationMs: 0, artifacts: [], timedOut: false };
      }
    }
    if (opts.artifactsDir) {
      try {
        await fsp.mkdir(opts.artifactsDir, { recursive: true });
        const safe = spec.name.replace(/[^A-Za-z0-9_-]/g, "_");
        const file = path.join(opts.artifactsDir, `${safe}-${Date.now()}.log`);
        await fsp.writeFile(file, `# ${command}\n# exit=${result.exitCode} passed=${result.passed} duration=${result.durationMs}ms\n\n## stdout\n${result.stdout}\n\n## stderr\n${result.stderr}\n`);
        result.artifacts.push(file);
      } catch {
        // artifact persistence is best-effort; the result itself is still returned
      }
    }
    await opts.bus?.emit({
      ...base,
      type: result.passed ? "test.passed" : "test.failed",
      durationMs: result.durationMs,
      error: result.passed ? null : `exit=${result.exitCode}${result.timedOut ? " (timeout)" : ""}`,
      data: { name: spec.name, kind: spec.kind, command, exitCode: result.exitCode, stderr: result.stderr.slice(0, 2000), artifacts: result.artifacts },
    });
    return result;
  }

  async runAll(specs: VerificationSpec[], opts: VerifyOptions): Promise<VerificationResult[]> {
    const out: VerificationResult[] = [];
    for (const s of specs) {
      if (opts.signal?.aborted) throw opts.signal.reason;
      out.push(await this.run(s, opts));
    }
    return out;
  }

  /** Evaluates declarative acceptance checks. Returns one result per check. */
  async runAcceptance(checks: AcceptanceCheck[], opts: VerifyOptions): Promise<{ check: AcceptanceCheck; passed: boolean; detail: string }[]> {
    const results: { check: AcceptanceCheck; passed: boolean; detail: string }[] = [];
    for (const check of checks) {
      if (opts.signal?.aborted) throw opts.signal.reason;
      try {
        switch (check.type) {
          case "file_exists": {
            const p = resolveSafePath(opts.workdir, check.path ?? "");
            await fsp.access(p);
            results.push({ check, passed: true, detail: `exists: ${check.path}` });
            break;
          }
          case "file_contains":
          case "file_not_contains": {
            const p = resolveSafePath(opts.workdir, check.path ?? "");
            const text = await fsp.readFile(p, "utf8");
            const has = text.includes(check.text ?? "");
            const passed = check.type === "file_contains" ? has : !has;
            results.push({ check, passed, detail: `${check.path} ${has ? "contains" : "does not contain"} ${JSON.stringify(check.text)}` });
            break;
          }
          case "command_succeeds": {
            const r = await this.run({ name: check.description ?? "acceptance", kind: "custom", command: check.command ?? "false" }, { ...opts, bus: null });
            results.push({ check, passed: r.passed, detail: `exit=${r.exitCode} ${r.stderr.slice(0, 300)}` });
            break;
          }
          default:
            results.push({ check, passed: false, detail: `unknown check type ${(check as AcceptanceCheck).type}` });
        }
      } catch (err) {
        results.push({ check, passed: false, detail: err instanceof Error ? err.message : String(err) });
      }
    }
    return results;
  }
}
